package com.jarvis.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import java.util.ArrayList;
import java.util.Locale;

/**
 * Foreground Service for "Hey Jarvis" Wake Word listening.
 * Runs continuously in the background or foreground, detects wake phrases,
 * and triggers MainActivity / WebView without blocking the UI.
 */
public class WakeWordService extends Service implements RecognitionListener {

    private static final String TAG = "WakeWordService";
    private static final String CHANNEL_ID = "jarvis_wake_word_channel";
    private static final int NOTIFICATION_ID = 2001;

    public interface WakeWordListener {
        void onWakeWordDetected();
        void onNativeCommandReceived(String command);
    }

    private final IBinder binder = new LocalBinder();
    private SpeechRecognizer speechRecognizer;
    private Intent recognizerIntent;
    private Handler handler;
    private WakeWordListener listener;
    private boolean isListening = false;
    private boolean isPaused = false;
    private boolean isServiceRunning = false;
    private long lastWakeAt = 0L;
    private static final long WAKE_COOLDOWN_MS = 2500L;
    private int consecutiveErrors = 0;
    private static final int MAX_RAPID_ERRORS = 4;

    public class LocalBinder extends Binder {
        public WakeWordService getService() {
            return WakeWordService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        createNotificationChannel();
        initRecognizer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForegroundNotification();
        isServiceRunning = true;
        startWakeWordListening();
        return START_STICKY;
    }

    public void setListener(WakeWordListener listener) {
        this.listener = listener;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "JARVIS Voice Core",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Continuous 'Hey Jarvis' Wake Word Detection");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void startForegroundNotification() {
        Intent notificationIntent = new Intent(this, MainActivity.class);
        notificationIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0
        );

        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }

        Notification notification = builder
                .setContentTitle("JARVIS V6 Voice Core")
                .setContentText("Listening for 'Hey Jarvis' wake word...")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void initRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "SpeechRecognizer not available on device");
            return;
        }

        if (speechRecognizer != null) {
            try {
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(this);

        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        recognizerIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
    }

    public synchronized void startWakeWordListening() {
        if (isPaused || isListening || speechRecognizer == null) return;
        try {
            isListening = true;
            speechRecognizer.startListening(recognizerIntent);
        } catch (Exception e) {
            Log.e(TAG, "Error starting speech listener", e);
            scheduleRestart(1000);
        }
    }

    public synchronized void stopWakeWordListening() {
        isListening = false;
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        if (speechRecognizer != null) {
            try {
                speechRecognizer.cancel();
            } catch (Exception ignored) {}
        }
    }

    public void setPaused(boolean paused) {
        this.isPaused = paused;
        if (paused) {
            stopWakeWordListening();
        } else {
            scheduleRestart(500);
        }
    }

    private void scheduleRestart(long delayMillis) {
        isListening = false;
        if (!isServiceRunning || isPaused) return;

        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler.postDelayed(() -> {
                if (isServiceRunning && !isPaused) {
                    startWakeWordListening();
                }
            }, delayMillis);
        }
    }

    // ==========================================
    // SpeechRecognizer Callbacks
    // ==========================================
    @Override
    public void onResults(Bundle results) {
        isListening = false;
        consecutiveErrors = 0;
        handleSpeechResults(results);
        scheduleRestart(600);
    }

    @Override
    public void onPartialResults(Bundle partialResults) {
        handleSpeechResults(partialResults);
    }

    private void handleSpeechResults(Bundle bundle) {
        if (bundle == null || isPaused) return;
        ArrayList<String> matches = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null || matches.isEmpty()) return;

        for (String match : matches) {
            String text = match.toLowerCase(Locale.US).trim();
            if (text.contains("hey jarvis") || text.contains("hey service") || 
                text.contains("jarvis") || text.contains("hello jarvis") || 
                text.contains("जार्विस") || text.contains("हे जार्विस")) {
                
                long now = System.currentTimeMillis();
                if (now - lastWakeAt < WAKE_COOLDOWN_MS) return;
                lastWakeAt = now;
                Log.i(TAG, "Wake word detected: " + text);
                
                // If the user said "Hey Jarvis [command]", extract the rest of the command!
                String cleanCommand = text.replaceFirst("(?i)^(hey |hello |ok )?jarvis[ ,:]*", "").trim();
                
                if (listener != null) {
                    listener.onWakeWordDetected();
                    if (!cleanCommand.isEmpty()) {
                        listener.onNativeCommandReceived(cleanCommand);
                    }
                }
                break;
            }
        }
    }

    @Override
    public void onError(int error) {
        isListening = false;
        consecutiveErrors++;

        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            Log.e(TAG, "Microphone permission missing in service");
            return;
        }

        long delay = 800;
        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
            delay = 1500;
        }

        // Exponential backoff if consecutive errors occur to avoid spinning loops
        if (consecutiveErrors >= MAX_RAPID_ERRORS) {
            delay = Math.min(6000, 1000L * consecutiveErrors);
            Log.w(TAG, "Multiple consecutive audio errors (" + consecutiveErrors + "). Backing off for " + delay + "ms");
        }

        scheduleRestart(delay);
    }

    @Override
    public void onReadyForSpeech(Bundle params) {
        consecutiveErrors = 0;
    }
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() { isListening = false; }
    @Override public void onEvent(int eventType, Bundle params) {}

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isServiceRunning = false;
        stopWakeWordListening();
        if (speechRecognizer != null) {
            try {
                speechRecognizer.destroy();
            } catch (Exception ignored) {}
            speechRecognizer = null;
        }
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
    }
}
