package com.jarvis.ai;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.net.URLEncoder;
import java.util.List;

/**
 * Android Native Javascript Bridge for JARVIS V6.
 * Exposes device capabilities to the JARVIS Web UI via window.AndroidBridge.
 */
public class JarvisAndroidBridge {

    private final Activity activity;
    private final MainActivity mainActivity;
    private final AudioManager audioManager;
    private final Vibrator vibrator;
    private boolean isFlashlightOn = false;

    public JarvisAndroidBridge(MainActivity mainActivity) {
        this.mainActivity = mainActivity;
        this.activity = mainActivity;
        this.audioManager = (AudioManager) activity.getSystemService(Context.AUDIO_SERVICE);
        this.vibrator = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
    }

    @JavascriptInterface
    public boolean isNativeAndroid() {
        return true;
    }

    // ==========================================
    // 1. FLASHLIGHT (TORCH) CONTROL
    // ==========================================
    @JavascriptInterface
    public boolean toggleFlashlight(boolean enable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                CameraManager cameraManager = (CameraManager) activity.getSystemService(Context.CAMERA_SERVICE);
                if (cameraManager != null) {
                    String[] cameraIds = cameraManager.getCameraIdList();
                    for (String id : cameraIds) {
                        CameraCharacteristics characteristics = cameraManager.getCameraCharacteristics(id);
                        Boolean hasFlash = characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                        if (hasFlash != null && hasFlash) {
                            cameraManager.setTorchMode(id, enable);
                            isFlashlightOn = enable;
                            vibrate(50);
                            return true;
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return false;
    }

    @JavascriptInterface
    public boolean isFlashlightActive() {
        return isFlashlightOn;
    }

    // ==========================================
    // 2. VOLUME CONTROLS
    // ==========================================
    @JavascriptInterface
    public int setVolume(int percentage) {
        if (audioManager == null) return -1;
        try {
            int maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int targetVol = (int) Math.round((percentage / 100.0) * maxVol);
            targetVol = Math.max(0, Math.min(targetVol, maxVol));
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, AudioManager.FLAG_SHOW_UI);
            vibrate(40);
            return (int) Math.round(((double) targetVol / maxVol) * 100);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    @JavascriptInterface
    public int adjustVolume(int delta) {
        if (audioManager == null) return -1;
        try {
            int direction = delta > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER;
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
            vibrate(40);
            int cur = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            return (int) Math.round(((double) cur / max) * 100);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    @JavascriptInterface
    public boolean muteVolume() {
        if (audioManager == null) return false;
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI);
            vibrate(40);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ==========================================
    // 3. SYSTEM SETTINGS LAUNCHERS
    // ==========================================
    @JavascriptInterface
    public boolean openSettings(String type) {
        try {
            Intent intent;
            String lower = type != null ? type.toLowerCase().trim() : "";
            switch (lower) {
                case "wifi":
                case "wi-fi":
                    intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    break;
                case "bluetooth":
                case "bt":
                    intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                    break;
                case "battery":
                case "power":
                    intent = new Intent(Intent.ACTION_POWER_USAGE_SUMMARY);
                    if (intent.resolveActivity(activity.getPackageManager()) == null) {
                        intent = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                    }
                    break;
                case "display":
                case "brightness":
                case "screen":
                    intent = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
                    break;
                case "notification":
                case "notifications":
                    intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    intent.putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
                    break;
                case "sound":
                case "volume":
                    intent = new Intent(Settings.ACTION_SOUND_SETTINGS);
                    break;
                default:
                    intent = new Intent(Settings.ACTION_SETTINGS);
                    break;
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
            vibrate(50);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            try {
                Intent fallback = new Intent(Settings.ACTION_SETTINGS);
                fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(fallback);
                return true;
            } catch (Exception ex) {
                return false;
            }
        }
    }

    // ==========================================
    // 4. APP LAUNCHER
    // ==========================================
    @JavascriptInterface
    public boolean launchApp(String appName) {
        if (appName == null || appName.trim().isEmpty()) return false;
        String name = appName.toLowerCase().trim();
        PackageManager pm = activity.getPackageManager();

        try {
            // Check known common apps
            if (name.contains("whatsapp")) {
                Intent intent = pm.getLaunchIntentForPackage("com.whatsapp");
                if (intent != null) {
                    activity.startActivity(intent);
                    return true;
                }
            } else if (name.contains("youtube")) {
                Intent intent = pm.getLaunchIntentForPackage("com.google.android.youtube");
                if (intent != null) {
                    activity.startActivity(intent);
                    return true;
                }
            } else if (name.contains("chrome") || name.contains("browser")) {
                Intent intent = pm.getLaunchIntentForPackage("com.android.chrome");
                if (intent != null) {
                    activity.startActivity(intent);
                    return true;
                }
            } else if (name.contains("camera")) {
                Intent intent = new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
                return true;
            } else if (name.contains("gallery") || name.contains("photos")) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setType("image/*");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
                return true;
            } else if (name.contains("settings")) {
                return openSettings("general");
            }

            // Search installed applications for matching label
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo app : apps) {
                String label = pm.getApplicationLabel(app).toString().toLowerCase();
                if (label.contains(name) || name.contains(label)) {
                    Intent launchIntent = pm.getLaunchIntentForPackage(app.packageName);
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        activity.startActivity(launchIntent);
                        vibrate(50);
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // App not found
        return false;
    }

    // ==========================================
    // 5. CALL & DIALER CONTROL
    // ==========================================
    @JavascriptInterface
    public boolean openDialer(String phoneNumber) {
        try {
            String uriString = "tel:";
            if (phoneNumber != null && !phoneNumber.trim().isEmpty()) {
                uriString += Uri.encode(phoneNumber.trim());
            }
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(uriString));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
            vibrate(50);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ==========================================
    // 6. SMS & WHATSAPP
    // ==========================================
    @JavascriptInterface
    public boolean openSms(String phoneNumber, String message) {
        try {
            Uri uri = Uri.parse("smsto:" + (phoneNumber != null ? phoneNumber.trim() : ""));
            Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
            if (message != null && !message.trim().isEmpty()) {
                intent.putExtra("sms_body", message.trim());
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
            vibrate(50);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @JavascriptInterface
    public boolean openWhatsApp(String phoneNumber, String message) {
        try {
            String url = "https://api.whatsapp.com/send?";
            if (phoneNumber != null && !phoneNumber.trim().isEmpty()) {
                String cleanNumber = phoneNumber.replaceAll("[^0-9+]", "");
                url += "phone=" + cleanNumber + "&";
            }
            if (message != null && !message.trim().isEmpty()) {
                url += "text=" + URLEncoder.encode(message.trim(), "UTF-8");
            }
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.setPackage("com.whatsapp");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                activity.startActivity(intent);
                return true;
            } catch (Exception noWhatsapp) {
                // Fallback to generic browser if WhatsApp app not installed
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(browserIntent);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ==========================================
    // 7. MEDIA CONTROLS
    // ==========================================
    @JavascriptInterface
    public boolean controlMedia(String action) {
        if (audioManager == null || action == null) return false;
        try {
            int keyCode = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE;
            String act = action.toLowerCase().trim();
            if (act.contains("pause")) {
                keyCode = KeyEvent.KEYCODE_MEDIA_PAUSE;
            } else if (act.contains("play")) {
                keyCode = KeyEvent.KEYCODE_MEDIA_PLAY;
            } else if (act.contains("next")) {
                keyCode = KeyEvent.KEYCODE_MEDIA_NEXT;
            } else if (act.contains("prev")) {
                keyCode = KeyEvent.KEYCODE_MEDIA_PREVIOUS;
            } else if (act.contains("stop")) {
                keyCode = KeyEvent.KEYCODE_MEDIA_STOP;
            }

            long eventTime = android.os.SystemClock.uptimeMillis();
            KeyEvent downEvent = new KeyEvent(eventTime, eventTime, KeyEvent.ACTION_DOWN, keyCode, 0);
            audioManager.dispatchMediaKeyEvent(downEvent);
            KeyEvent upEvent = new KeyEvent(eventTime, eventTime, KeyEvent.ACTION_UP, keyCode, 0);
            audioManager.dispatchMediaKeyEvent(upEvent);
            vibrate(30);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ==========================================
    // 8. BATTERY & SENSORS
    // ==========================================
    @JavascriptInterface
    public int getBatteryLevel() {
        try {
            BatteryManager bm = (BatteryManager) activity.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    @JavascriptInterface
    public boolean isBatteryCharging() {
        try {
            BatteryManager bm = (BatteryManager) activity.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) {
                int status = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS);
                return status == BatteryManager.BATTERY_STATUS_CHARGING ||
                       status == BatteryManager.BATTERY_STATUS_FULL;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ==========================================
    // 9. WAKE WORD TOGGLE & NOTIFICATIONS
    // ==========================================
    @JavascriptInterface
    public void setWakeWordEnabled(boolean enabled) {
        activity.runOnUiThread(() -> {
            mainActivity.setWakeWordEnabled(enabled);
        });
    }

    @JavascriptInterface
    public void onAssistantSpeaking(boolean isSpeaking) {
        // Pause or resume wake-word listening while JARVIS is vocalizing
        mainActivity.setAssistantSpeaking(isSpeaking);
    }

    @JavascriptInterface
    public void vibrate(int milliseconds) {
        if (vibrator != null && vibrator.hasVibrator()) {
            try {
                vibrator.vibrate(milliseconds);
            } catch (Exception ignored) {}
        }
    }

    @JavascriptInterface
    public void showToast(String message) {
        if (message != null && !message.isEmpty()) {
            activity.runOnUiThread(() -> Toast.makeText(activity, message, Toast.LENGTH_SHORT).show());
        }
    }
}
