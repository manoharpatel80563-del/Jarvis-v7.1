import React from 'react';
import { X, HelpCircle, Sparkles, Mic, Play, ShieldCheck } from 'lucide-react';

interface HelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTestCommand: (cmd: string) => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({
  isOpen,
  onClose,
  onTestCommand,
}) => {
  if (!isOpen) return null;

  const commandGroups = [
    {
      category: 'ANDROID NATIVE PHONE CONTROLS (V6)',
      commands: [
        {
          title: 'फ्लैशलाइट टॉर्च (Torch / Flashlight)',
          phrases: ['"Torch on karo"', '"Torch band karo"', '"Turn on flashlight"'],
          action: 'Torch on karo',
        },
        {
          title: 'वॉल्यूम नियंत्रण (Volume Control)',
          phrases: ['"Volume badhao"', '"Volume kam karo"', '"Mute volume"'],
          action: 'Volume badhao',
        },
        {
          title: 'सिस्टम सेटिंग्स (Android Settings)',
          phrases: ['"Open settings"', '"Open WiFi"', '"Open Bluetooth"'],
          action: 'Open WiFi',
        },
        {
          title: 'ऐप लॉन्चर (Launch Any App)',
          phrases: ['"Open Camera"', '"Open WhatsApp"', '"Open YouTube"'],
          action: 'Open Camera',
        },
        {
          title: 'मीडिया एवं म्यूजिक (Music Playback)',
          phrases: ['"Play music"', '"Pause music"', '"Next song"'],
          action: 'Play music',
        },
      ],
    },
    {
      category: 'DEVICE & TELEMETRY COMMANDS',
      commands: [
        {
          title: 'समय (Current Time)',
          phrases: ['"समय बताओ"', '"Time batao"', '"What time is it"'],
          action: 'समय बताओ',
        },
        {
          title: 'तारीख (Today’s Date)',
          phrases: ['"आज की तारीख बताओ"', '"Date batao"', '"Today’s date"'],
          action: 'आज की तारीख बताओ',
        },
        {
          title: 'बैटरी (Battery Status)',
          phrases: ['"Battery बताओ"', '"Phone battery"', '"Battery kitni hai"'],
          action: 'battery बताओ',
        },
        {
          title: 'इंटरनेट (Internet Status)',
          phrases: ['"Internet बताओ"', '"Network status"', '"Online status"'],
          action: 'internet बताओ',
        },
      ],
    },
    {
      category: 'APP LAUNCHERS & PHONE ACTIONS',
      commands: [
        {
          title: 'Google Search',
          phrases: ['"Google पर AI news search करो"', '"Search python on Google"'],
          action: 'Google पर AI news search करो',
        },
        {
          title: 'YouTube Launcher',
          phrases: ['"YouTube पर lofi music search करो"', '"YouTube खोलो"'],
          action: 'YouTube पर lofi music search करो',
        },
        {
          title: 'WhatsApp Opener',
          phrases: ['"WhatsApp खोलो"', '"Open WhatsApp"'],
          action: 'WhatsApp खोलो',
        },
        {
          title: 'Phone Call / Dialer',
          phrases: ['"Call 9876543210"', '"फोन लगाओ 100"'],
          action: 'Call 9876543210',
        },
      ],
    },
    {
      category: 'GEMINI AI INTELLIGENCE',
      commands: [
        {
          title: 'Natural Conversation & Wake Word',
          phrases: ['"Hey JARVIS"', '"हेलो जार्विस"', '"नमस्ते जार्विस"'],
          action: 'नमस्ते जार्विस, आप कैसे हैं?',
        },
        {
          title: 'Knowledge & Explanations',
          phrases: ['"ब्लैक होल क्या होता है सरल शब्दों में समझाओ"', '"Explain quantum computing"'],
          action: 'ब्लैक होल क्या होता है सरल शब्दों में समझाओ',
        },
        {
          title: 'Translation & Hinglish Help',
          phrases: ['"Translate this email to formal Hindi"', '"Hinglish to English"'],
          action: 'Explain machine learning in Hinglish',
        },
        {
          title: 'Coding, Math & Problem Solving',
          phrases: ['"Write a React hook for debounce"', '"Solve 25 * 48"'],
          action: 'Write a quick React code snippet for a counter',
        },
      ],
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-lg max-h-[90vh] flex flex-col rounded-2xl border border-cyan-500/40 bg-gray-950 p-5 text-cyan-50 shadow-[0_0_40px_rgba(6,182,212,0.3)]">
        {/* Close Button */}
        <button
          id="btn-close-help"
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full border border-cyan-900 bg-gray-900 text-cyan-400 hover:bg-cyan-900/50"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Title */}
        <div className="flex items-center gap-2 mb-2">
          <HelpCircle className="w-5 h-5 text-cyan-400" />
          <h3 className="text-base font-bold font-['Orbitron'] tracking-wider text-cyan-200">
            JARVIS V5 COMMAND MANUAL
          </h3>
        </div>
        <p className="text-xs font-mono text-cyan-400/80 mb-3">
          बोलकर या टाइप करके इनमें से कोई भी कमांड निष्पादित करें।
        </p>

        {/* Scrollable Command Catalog */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-4 font-mono">
          {commandGroups.map((group, gIdx) => (
            <div key={gIdx} className="space-y-2">
              <h4 className="text-[11px] font-bold tracking-widest text-cyan-400 uppercase border-b border-cyan-900/50 pb-1 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                {group.category}
              </h4>
              <div className="grid grid-cols-1 gap-2">
                {group.commands.map((cmd, cIdx) => (
                  <div
                    key={cIdx}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 rounded-xl border border-cyan-950 bg-gray-900/60 hover:border-cyan-500/30 gap-2"
                  >
                    <div>
                      <div className="text-xs font-bold text-cyan-200 font-sans">{cmd.title}</div>
                      <div className="text-[11px] text-cyan-400/70">{cmd.phrases.join(' • ')}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        onTestCommand(cmd.action);
                        onClose();
                      }}
                      className="self-start sm:self-auto flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-cyan-500/40 bg-cyan-950/40 text-cyan-300 text-[11px] font-bold hover:bg-cyan-900/50 hover:border-cyan-300 active:scale-95 transition-all"
                    >
                      <Play className="w-3 h-3" />
                      <span>Try Command</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Guidelines info */}
          <div className="p-3 rounded-xl border border-cyan-900/40 bg-cyan-950/20 text-xs font-sans text-cyan-300/90 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
            <span>
              <strong>Tip</strong>: You can speak naturally in pure Hindi, Hinglish, or English. JARVIS adapts automatically and responds in the same language.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
