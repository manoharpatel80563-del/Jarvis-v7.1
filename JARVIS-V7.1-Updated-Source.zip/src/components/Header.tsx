import React, { useState } from 'react';
import {
  Wifi,
  WifiOff,
  BatteryCharging,
  Battery,
  Volume2,
  VolumeX,
  Settings,
  HelpCircle,
  Smartphone,
  Menu,
  X,
  Sparkles,
} from 'lucide-react';
import { BatteryInfo, NetworkInfo } from '../types';

interface HeaderProps {
  network: NetworkInfo;
  battery: BatteryInfo;
  autoSpeak: boolean;
  onToggleAutoSpeak: () => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
  onOpenApkModal: () => void;
  isOfflineMode?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  network,
  battery,
  autoSpeak,
  onToggleAutoSpeak,
  onOpenSettings,
  onOpenHelp,
  onOpenApkModal,
  isOfflineMode = false,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="w-full max-w-2xl mx-auto px-2 sm:px-4 pt-2.5 pb-2 border-b border-cyan-950/70 bg-gray-950/90 backdrop-blur-md sticky top-0 z-40 select-none">
      <div className="flex items-center justify-between gap-2">
        {/* Brand Title (Compact on Mobile, Full on larger screens) */}
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0 flex-shrink">
          <span className="h-2 w-2 rounded-full bg-cyan-400 animate-ping flex-shrink-0" />
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-lg sm:text-2xl font-black tracking-wider sm:tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-200 to-cyan-400 font-['Orbitron'] truncate">
                J.A.R.V.I.S.
              </h1>
              <span className="text-[9px] sm:text-[10px] uppercase font-bold tracking-wider px-1 sm:px-1.5 py-0.2 rounded border border-cyan-500/40 bg-cyan-950/60 text-cyan-300 flex-shrink-0">
                V7
              </span>
            </div>
            <span className="hidden xs:inline text-[9px] sm:text-[10px] tracking-wider text-cyan-400/70 font-mono truncate">
              HINDI • HINGLISH • ENGLISH
            </span>
          </div>
        </div>

        {/* Telemetry Indicator (Compact combined pill on mobile) */}
        <div className="hidden md:flex items-center gap-1.5">
          {/* Network Badge */}
          <div
            title={network.online ? 'Network Connected' : 'Offline Mode Active'}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-mono border ${
              network.online && !isOfflineMode
                ? 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300'
                : 'border-amber-500/40 bg-amber-950/40 text-amber-300'
            }`}
          >
            {network.online && !isOfflineMode ? (
              <Wifi className="w-3 h-3 text-cyan-400" />
            ) : (
              <WifiOff className="w-3 h-3 text-amber-400" />
            )}
            <span>{network.online && !isOfflineMode ? 'ONLINE' : 'OFFLINE'}</span>
          </div>

          {/* Battery Badge */}
          {battery.supported && (
            <div
              title={`Battery: ${battery.level}% ${battery.charging ? '(Charging)' : ''}`}
              className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-mono border border-cyan-500/30 bg-cyan-950/40 text-cyan-300"
            >
              {battery.charging ? (
                <BatteryCharging className="w-3 h-3 text-emerald-400 animate-pulse" />
              ) : (
                <Battery className="w-3 h-3 text-cyan-400" />
              )}
              <span>{battery.level}%</span>
            </div>
          )}
        </div>

        {/* Primary Controls Row - ALWAYS visible on all screen sizes */}
        <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
          {/* Mute / Unmute Toggle */}
          <button
            id="btn-toggle-voice-output"
            type="button"
            onClick={onToggleAutoSpeak}
            title={autoSpeak ? 'Voice output enabled (Click to mute)' : 'Voice output muted (Click to unmute)'}
            aria-label="Toggle Voice Output"
            className={`p-1.5 sm:p-2 rounded-lg border transition-all ${
              autoSpeak
                ? 'border-cyan-500/50 bg-cyan-950/60 text-cyan-300 hover:bg-cyan-900/60 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                : 'border-gray-800 bg-gray-900/60 text-gray-500 hover:text-gray-300'
            }`}
          >
            {autoSpeak ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Android APK Button (Icon on small mobile, pill on sm+) */}
          <button
            id="btn-header-apk"
            type="button"
            onClick={onOpenApkModal}
            title="Download Android APK"
            aria-label="Download APK"
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg border border-cyan-500/40 bg-cyan-950/50 text-cyan-300 hover:bg-cyan-900/60 hover:border-cyan-400 text-xs font-mono font-bold transition-all"
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline text-[11px]">APK</span>
          </button>

          {/* Desktop Help Button */}
          <button
            id="btn-header-help"
            type="button"
            onClick={onOpenHelp}
            title="Command Reference & Help"
            aria-label="Help"
            className="hidden sm:flex p-2 rounded-lg border border-cyan-500/30 bg-cyan-950/30 text-cyan-300 hover:bg-cyan-900/50 hover:text-cyan-100 transition-all"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* PROMINENT SETTINGS BUTTON - GUARANTEED ALWAYS VISIBLE & CLICKABLE ON MOBILE */}
          <button
            id="btn-header-settings"
            type="button"
            onClick={onOpenSettings}
            title="Open JARVIS Settings"
            aria-label="Settings"
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg border border-cyan-400/80 bg-gradient-to-r from-cyan-950/90 to-sky-950/80 text-cyan-200 hover:border-cyan-300 hover:bg-cyan-900/80 shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95 transition-all text-xs font-mono font-bold cursor-pointer"
          >
            <Settings className="w-4 h-4 text-cyan-300 animate-[spin_12s_linear_infinite]" />
            <span className="text-[11px] tracking-wider">SETTINGS</span>
          </button>

          {/* Mobile Quick Menu Toggle for narrow screens */}
          <button
            id="btn-mobile-menu"
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            title="More Options"
            aria-label="Open mobile menu"
            className="sm:hidden p-1.5 rounded-lg border border-cyan-500/30 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/50"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu for secondary telemetry and shortcuts */}
      {mobileMenuOpen && (
        <div className="sm:hidden mt-2 pt-2 border-t border-cyan-900/50 flex flex-col gap-2 font-mono text-xs animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center justify-between px-1 text-[11px] text-cyan-400/80">
            <span className="flex items-center gap-1">
              {network.online && !isOfflineMode ? (
                <Wifi className="w-3 h-3 text-cyan-400" />
              ) : (
                <WifiOff className="w-3 h-3 text-amber-400" />
              )}
              {network.online && !isOfflineMode ? 'Status: Online' : 'Status: Offline'}
            </span>
            {battery.supported && (
              <span className="flex items-center gap-1">
                <Battery className="w-3 h-3 text-cyan-400" />
                Battery: {battery.level}% {battery.charging ? '(⚡)' : ''}
              </span>
            )}
          </div>

          <div className="grid grid-cols-2 gap-1.5 pt-1">
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSettings();
              }}
              className="flex items-center justify-center gap-1.5 p-2 rounded-lg border border-cyan-500/40 bg-cyan-950/70 text-cyan-200 font-bold"
            >
              <Settings className="w-3.5 h-3.5 text-cyan-400" />
              <span>Settings ⚙️</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenHelp();
              }}
              className="flex items-center justify-center gap-1.5 p-2 rounded-lg border border-cyan-500/30 bg-gray-900/70 text-cyan-300"
            >
              <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
              <span>Help & Commands</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
