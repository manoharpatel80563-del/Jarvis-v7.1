/**
 * Smart Command Engine & Wake Phrase Processor for JARVIS V6
 * Handles wake phrase stripping, stop commands, calculations, device telemetry, redirects, and phone dialer.
 */

export interface SmartCommandExecution {
  handled: boolean;
  spokenReply: string;
  displayText: string;
  actionUrl?: string;
  actionLabel?: string;
  actionType?: 'url' | 'dialer' | 'help' | 'info' | 'wake' | 'calc' | 'stop';
  metadata?: any;
}

export interface WakePhraseResult {
  hasWakePhrase: boolean;
  isWakeOnly: boolean;
  cleanedText: string;
}

/**
 * Detects explicit voice stop commands such as:
 * "Stop Jarvis", "Jarvis stop", "Band ho jao", "Bas Jarvis", "Stop listening",
 * "सुनना बंद करो", "जार्विस बंद हो जाओ", "standby", "ruk jao", etc.
 */
export function isStopCommand(rawText: string): boolean {
  if (!rawText) return false;
  const text = rawText.toLowerCase().trim().replace(/[?!.,;:]+$/g, '');
  const stopPatterns = [
    /^stop\s+jarvis$/i,
    /^jarvis\s+stop$/i,
    /^stop$/i,
    /^band\s+ho\s+jao$/i,
    /^jarvis\s+band\s+ho\s+jao$/i,
    /^band\s+ho\s+jao\s+jarvis$/i,
    /^bas\s+jarvis$/i,
    /^jarvis\s+bas$/i,
    /^stop\s+listening$/i,
    /^jarvis\s+stop\s+listening$/i,
    /^listen\s+stop$/i,
    /^standby$/i,
    /^go\s+to\s+standby$/i,
    /^jarvis\s+standby$/i,
    /^ruk\s+jao$/i,
    /^jarvis\s+ruk\s+jao$/i,
    /^chup\s+ho\s+jao$/i,
    /^chup\s+raho$/i,
    /^(?:सुनना\s*बंद\s*करो|जार्विस\s*सुनना\s*बंद\s*करो|जार्विस\s*बंद\s*हो\s*जाओ|बंद\s*हो\s*जाओ|बस\s*जार्विस|जार्विस\s*बस|स्टैंडबाय|रुक\s*जाओ|चुप\s*हो\s*जाओ)$/u,
  ];
  return stopPatterns.some((pattern) => pattern.test(text));
}

/**
 * Detects wake phrases such as "Hey Jarvis", "Hey JARVIS", "Jarvis", "हे जार्विस", etc.
 * Cleans the input so subsequent command matching receives the actual query without wake words.
 */
export function parseWakePhrase(rawInput: string): WakePhraseResult {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    return { hasWakePhrase: false, isWakeOnly: false, cleanedText: '' };
  }

  // Variations:
  // English/Hinglish: "hey jarvis", "hello jarvis", "hi jarvis", "ok jarvis", "okay jarvis", "oye jarvis", "suno jarvis", "jarvis"
  // Hindi: "हे जार्विस", "हेलो जार्विस", "नमस्ते जार्विस", "अरे जार्विस", "सुनो जार्विस", "जार्विस", "ज़ार्विस"
  const wakeRegex = /^(?:hey\s+jarvis|hello\s+jarvis|hi\s+jarvis|ok\s+jarvis|okay\s+jarvis|oye\s+jarvis|suno\s+jarvis|jarvis|हे\s+जार्विस|हेलो\s+जार्विस|नमस्ते\s+जार्विस|अरे\s+जार्विस|सुनो\s+जार्विस|जार्विस|ज़ार्विस)[,\s:!-.]*/i;

  const match = trimmed.match(wakeRegex);
  if (!match) {
    return {
      hasWakePhrase: false,
      isWakeOnly: false,
      cleanedText: trimmed,
    };
  }

  const remainder = trimmed.slice(match[0].length).replace(/^[,\s:!-]+/, '').trim();
  if (!remainder) {
    return {
      hasWakePhrase: true,
      isWakeOnly: true,
      cleanedText: '',
    };
  }

  return {
    hasWakePhrase: true,
    isWakeOnly: false,
    cleanedText: remainder,
  };
}

/**
 * Safely evaluates basic math expressions without eval or Function constructor.
 * Handles questions like:
 * "2 plus 2 kitna hai?", "5 plus 5 kitna hai?", "Achha 5 plus 5?", "10 * 5", "100 divided by 4"
 */
export function tryCalculateMath(rawText: string): { expr: string; result: number } | null {
  let text = rawText.toLowerCase().trim();

  // Strip trailing punctuation
  text = text.replace(/[?!.,;:]+$/g, '');

  // Strip conversational prefixes and fillers (e.g., "achha", "accha", "aur", "ab", "to", "batao", "jarvis")
  text = text.replace(/^(?:achha|accha|acha|aur|ab|to|batao|theek\s*hai|thik\s*hai|bhai|sir|jarvis|अच्छा|और|अब|तो|बताओ|ठीक\s*है|जार्विस)[,\s]+/gi, '');

  // Strip common query suffixes/prefixes in Hindi and English
  text = text.replace(/\b(kitna\s*hai|kitna\s*hota\s*hai|kya\s*hai|kya\s*hoga|batao|bataiye|calculate|karo|kijiye|hoga|barabar|equals?)\b/gi, '');
  text = text.replace(/(कितना\s*है|कितना\s*होता\s*है|क्या\s*है|क्या\s*होगा|बताओ|बताइए|बराबर|हिसाब\s*करो)/gi, '');

  // Normalize operator words into arithmetic symbols
  text = text.replace(/\b(multiplied\s*by|into|times|guna|गुना|गुणा)\b/gi, '*');
  text = text.replace(/\b(divided\s*by|divide|bhaag|भाग|डिवाइड)\b/gi, '/');
  text = text.replace(/\b(plus|jod|जोड़|प्लस)\b/gi, '+');
  text = text.replace(/\b(minus|ghatao|घटाओ|माइनस)\b/gi, '-');
  text = text.replace(/[xX]/g, '*');
  text = text.trim();

  // Validate that text consists ONLY of numbers, spaces, decimals, and operators +, -, *, /, (, )
  if (!/^[\d\s+\-*/.()]+$/.test(text)) {
    return null;
  }
  // Must contain at least one arithmetic operator
  if (!/[+\-*/]/.test(text)) {
    return null;
  }

  try {
    const tokens = text.match(/(\d+\.?\d*|[+\-*/()])/g);
    if (!tokens || tokens.length < 3) return null;

    let idx = 0;
    const parseNumber = (): number => {
      const token = tokens[idx++];
      if (token === '(') {
        const val = parseExpr();
        if (tokens[idx] === ')') idx++;
        return val;
      }
      return parseFloat(token);
    };

    const parseFactor = (): number => {
      let val = parseNumber();
      while (idx < tokens.length && (tokens[idx] === '*' || tokens[idx] === '/')) {
        const op = tokens[idx++];
        const next = parseNumber();
        if (op === '*') val = val * next;
        else if (op === '/') val = next !== 0 ? val / next : NaN;
      }
      return val;
    };

    const parseExpr = (): number => {
      let val = parseFactor();
      while (idx < tokens.length && (tokens[idx] === '+' || tokens[idx] === '-')) {
        const op = tokens[idx++];
        const next = parseFactor();
        if (op === '+') val = val + next;
        else if (op === '-') val = val - next;
      }
      return val;
    };

    const res = parseExpr();
    if (isNaN(res) || !isFinite(res)) return null;

    const cleanResult = Number.isInteger(res) ? res : parseFloat(res.toFixed(4));
    return {
      expr: text.replace(/\s+/g, ' '),
      result: cleanResult,
    };
  } catch {
    return null;
  }
}

/**
 * Checks for and executes local/device commands.
 * Returns SmartCommandExecution if handled locally, or null if query should be routed to Gemini AI.
 */
export async function checkAndExecuteSmartCommand(rawInput: string): Promise<SmartCommandExecution | null> {
  const text = rawInput.trim();
  const lower = text.toLowerCase();

  // 0. STOP COMMAND
  // When user says "Stop Jarvis", "Jarvis stop", "Band ho jao", "Bas Jarvis", "सुनना बंद करो", "जार्विस बंद हो जाओ", etc.
  if (isStopCommand(text) || isStopCommand(rawInput)) {
    return {
      handled: true,
      spokenReply: 'Ji, main standby mode mein hoon.',
      displayText: '🛑 **JARVIS V6**: Ji, main standby mode mein hoon.\n(जी, मैं स्टैंडबाय मोड में हूँ। पुनः शुरू करने के लिए "Hey Jarvis" बोलें।)',
      actionType: 'stop',
    };
  }

  // =========================================================================
  // 1.1 ANDROID NATIVE PHONE CONTROLS (Flashlight, Volume, Settings, Media, Apps)
  // =========================================================================
  
  // A. FLASHLIGHT / TORCH CONTROL
  const isFlashlightOn =
    lower.includes('turn on flashlight') ||
    lower.includes('flashlight on') ||
    lower.includes('torch on') ||
    lower.includes('turn on torch') ||
    lower.includes('torch jalao') ||
    lower.includes('flashlight jalao') ||
    text.includes('टॉर्च चालू') ||
    text.includes('टॉर्च जलाओ') ||
    text.includes('फ्लैशलाइट ऑन');

  const isFlashlightOff =
    lower.includes('turn off flashlight') ||
    lower.includes('flashlight off') ||
    lower.includes('torch off') ||
    lower.includes('turn off torch') ||
    lower.includes('torch band') ||
    lower.includes('flashlight band') ||
    text.includes('टॉर्च बंद') ||
    text.includes('फ्लैशलाइट बंद');

  if (isFlashlightOn || isFlashlightOff) {
    const turnOn = isFlashlightOn;
    let handledLocally = false;

    if (typeof window !== 'undefined' && window.AndroidBridge?.toggleFlashlight) {
      handledLocally = window.AndroidBridge.toggleFlashlight(turnOn);
    }

    const spoken = turnOn
      ? (handledLocally ? 'सर, फ्लैशलाइट चालू कर दी गई है।' : 'सर, डिवाइस फ्लैशलाइट टॉर्च ऑन कमांड भेजा गया है।')
      : (handledLocally ? 'सर, फ्लैशलाइट बंद कर दी गई है।' : 'सर, डिवाइस फ्लैशलाइट टॉर्च ऑफ़ कमांड भेजा गया है।');

    const display = turnOn
      ? `🔦 **फ्लैशलाइट (Torch)**: 💡 **चालू (ON)**\n${handledLocally ? 'डिवाइस कैमरा टॉर्च सक्रिय है।' : 'डिवाइस हार्डवेयर टॉर्च सक्रिय करने का प्रयास किया गया।'}`
      : `🔦 **फ्लैशलाइट (Torch)**: 🌑 **बंद (OFF)**\n${handledLocally ? 'डिवाइस कैमरा टॉर्च बंद है।' : 'डिवाइस हार्डवेयर टॉर्च बंद किया गया।'}`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'info',
    };
  }

  // B. VOLUME CONTROLS
  const isVolumeMute =
    lower.includes('mute volume') ||
    lower.includes('mute awaz') ||
    lower.includes('volume mute') ||
    lower.includes('chup ho jao') ||
    lower.includes('awaz band') ||
    text.includes('आवाज बंद') ||
    text.includes('म्यूट करो');

  const isVolumeUp =
    lower.includes('increase volume') ||
    lower.includes('volume up') ||
    lower.includes('volume badhao') ||
    lower.includes('awaz badhao') ||
    text.includes('आवाज बढ़ाओ') ||
    text.includes('वॉल्यूम बढ़ाओ');

  const isVolumeDown =
    lower.includes('decrease volume') ||
    lower.includes('volume down') ||
    lower.includes('volume kam') ||
    lower.includes('awaz kam') ||
    text.includes('आवाज कम') ||
    text.includes('वॉल्यूम कम');

  const volumeSetMatch = lower.match(/(?:set volume to|volume karo|volume rakhna)\s*(\d+)\s*(?:percent|%)?/i);

  if (isVolumeMute || isVolumeUp || isVolumeDown || volumeSetMatch) {
    let resultLevel = -1;
    let spokenText = '';
    let displayText = '';

    if (isVolumeMute) {
      if (typeof window !== 'undefined' && window.AndroidBridge?.muteVolume) {
        window.AndroidBridge.muteVolume();
      }
      spokenText = 'सर, मीडिया वॉल्यूम म्यूट कर दिया गया है।';
      displayText = '🔇 **वॉल्यूम नियंत्रण**: म्यूट (0%)';
    } else if (volumeSetMatch) {
      const targetPercent = parseInt(volumeSetMatch[1], 10);
      if (typeof window !== 'undefined' && window.AndroidBridge?.setVolume) {
        resultLevel = window.AndroidBridge.setVolume(targetPercent);
      }
      spokenText = `सर, वॉल्यूम ${targetPercent} प्रतिशत पर सेट कर दिया गया है।`;
      displayText = `🔊 **वॉल्यूम नियंत्रण**: सेट किया गया **${targetPercent}%**`;
    } else if (isVolumeUp) {
      if (typeof window !== 'undefined' && window.AndroidBridge?.adjustVolume) {
        resultLevel = window.AndroidBridge.adjustVolume(1);
      }
      spokenText = 'सर, वॉल्यूम बढ़ा दिया गया है।';
      displayText = `🔊 **वॉल्यूम नियंत्रण**: बढ़ा दिया गया ${resultLevel >= 0 ? `(${resultLevel}%)` : ''}`;
    } else if (isVolumeDown) {
      if (typeof window !== 'undefined' && window.AndroidBridge?.adjustVolume) {
        resultLevel = window.AndroidBridge.adjustVolume(-1);
      }
      spokenText = 'सर, वॉल्यूम कम कर दिया गया है।';
      displayText = `🔉 **वॉल्यूम नियंत्रण**: कम कर दिया गया ${resultLevel >= 0 ? `(${resultLevel}%)` : ''}`;
    }

    return {
      handled: true,
      spokenReply: spokenText,
      displayText,
      actionType: 'info',
    };
  }

  // C. ANDROID SETTINGS (WiFi, Bluetooth, Battery, Display, Notification)
  const isSettingsCommand =
    lower.includes('open settings') ||
    lower.includes('settings kholo') ||
    lower.includes('open wifi') ||
    lower.includes('wifi kholo') ||
    lower.includes('open bluetooth') ||
    lower.includes('bluetooth kholo') ||
    lower.includes('display settings') ||
    lower.includes('notification settings') ||
    text.includes('सेटिंग्स खोलो') ||
    text.includes('वाईफाई खोलो') ||
    text.includes('ब्लूटूथ खोलो');

  if (isSettingsCommand) {
    let settingType = 'general';
    let label = 'Android Settings';

    if (lower.includes('wifi') || text.includes('वाईफाई')) {
      settingType = 'wifi';
      label = 'Wi-Fi Settings';
    } else if (lower.includes('bluetooth') || text.includes('ब्लूटूथ')) {
      settingType = 'bluetooth';
      label = 'Bluetooth Settings';
    } else if (lower.includes('battery') || text.includes('बैटरी')) {
      settingType = 'battery';
      label = 'Battery Settings';
    } else if (lower.includes('display') || lower.includes('brightness') || text.includes('डिस्प्ले')) {
      settingType = 'display';
      label = 'Display Settings';
    } else if (lower.includes('notification') || text.includes('नोटिफिकेशन')) {
      settingType = 'notification';
      label = 'Notification Settings';
    }

    let opened = false;
    if (typeof window !== 'undefined' && window.AndroidBridge?.openSettings) {
      opened = window.AndroidBridge.openSettings(settingType);
    }

    const spoken = `सर, ${label} खोला जा रहा है।`;
    const display = `⚙️ **${label}**:\n${opened ? 'एंड्रॉइड सेटिंग्स स्क्रीन खोली गई।' : 'सिस्टम सेटिंग्स खोलने के लिए कमांड निष्पादित किया गया।'}`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'info',
    };
  }

  // D. MEDIA PLAYBACK CONTROLS (Play, Pause, Next, Previous)
  const isMediaControl =
    lower.includes('play music') ||
    lower.includes('pause music') ||
    lower.includes('gana bajao') ||
    lower.includes('gana roko') ||
    lower.includes('next song') ||
    lower.includes('previous song') ||
    lower.includes('agla gana') ||
    lower.includes('pichla gana') ||
    text.includes('गाना बजाओ') ||
    text.includes('गाना रोको') ||
    text.includes('अगला गाना') ||
    text.includes('पिछला गाना');

  if (isMediaControl) {
    let mediaAction = 'play_pause';
    let label = 'Media Play/Pause';

    if (lower.includes('pause') || lower.includes('roko') || text.includes('रोको')) {
      mediaAction = 'pause';
      label = 'Pause Music';
    } else if (lower.includes('play') || lower.includes('bajao') || text.includes('बजाओ')) {
      mediaAction = 'play';
      label = 'Play Music';
    } else if (lower.includes('next') || lower.includes('agla') || text.includes('अगला')) {
      mediaAction = 'next';
      label = 'Next Track';
    } else if (lower.includes('prev') || lower.includes('pichla') || text.includes('पिछला')) {
      mediaAction = 'prev';
      label = 'Previous Track';
    }

    if (typeof window !== 'undefined' && window.AndroidBridge?.controlMedia) {
      window.AndroidBridge.controlMedia(mediaAction);
    }

    const spoken = `सर, ${label} कमांड निष्पादित किया गया।`;
    const display = `🎵 **मीडिया नियंत्रण**: ${label}`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'info',
    };
  }

  // E. APP LAUNCHER (Camera, WhatsApp, YouTube, Chrome, Gallery, etc.)
  const appLaunchMatch = lower.match(/(?:open|kholo|chalao)\s+([a-z0-9\s]+)/i);
  const hindiAppMatch = text.match(/([^\s]+)\s*(?:खोलो|ओपन करो|चलाओ)/u);

  if (appLaunchMatch || hindiAppMatch) {
    const candidateApp = (appLaunchMatch ? appLaunchMatch[1] : (hindiAppMatch ? hindiAppMatch[1] : '')).trim().toLowerCase();
    
    // Check if it's a known non-app keyword
    const nonApps = ['settings', 'wifi', 'bluetooth', 'battery', 'time', 'date', 'internet', 'help'];
    if (candidateApp && !nonApps.includes(candidateApp) && !candidateApp.includes('search')) {
      if (typeof window !== 'undefined' && window.AndroidBridge?.launchApp) {
        const launched = window.AndroidBridge.launchApp(candidateApp);
        if (launched) {
          const spoken = `सर, ${candidateApp} खोला जा रहा है।`;
          const display = `📱 **ऐप लॉन्चर**: ${candidateApp} लॉन्च किया गया।`;
          return {
            handled: true,
            spokenReply: spoken,
            displayText: display,
            actionType: 'info',
          };
        } else if (window.isJarvisAndroidApp) {
          // Native app explicitly returned false (not installed)
          const spoken = 'Ye app aapke phone me installed nahi hai.';
          const display = `⚠️ **ऐप नहीं मिला**: "${candidateApp}" आपके फोन में स्थापित (installed) नहीं है।`;
          return {
            handled: true,
            spokenReply: spoken,
            displayText: display,
            actionType: 'info',
          };
        }
      }
    }
  }

  // 1.2 STANDALONE WAKE PHRASE
  // If the user says only "Hey Jarvis", "हे जार्विस" without a trailing command:
  const wakeCheck = parseWakePhrase(rawInput);
  if (wakeCheck.hasWakePhrase && wakeCheck.isWakeOnly) {
    return {
      handled: true,
      spokenReply: 'Ji, main sun raha hoon.',
      displayText: '🎙️ **JARVIS V6**: Ji, main sun raha hoon.\n(जी, मैं सुन रहा हूँ। कहिए सर, क्या आदेश है?)',
      actionType: 'wake',
    };
  }

  // 2. BASIC CALCULATIONS (e.g., "2 plus 2 kitna hai?", "5 plus 5 kitna hai?", "Achha 5 plus 5?")
  const mathCalc = tryCalculateMath(text);
  if (mathCalc) {
    const spoken = `${mathCalc.result}`;
    const display = `🔢 **गणना (Calculation)**:\n• अभिव्यक्ति: **${mathCalc.expr}**\n• उत्तर: **${mathCalc.result}**`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'calc',
      metadata: mathCalc,
    };
  }

  // 3. TIME COMMAND
  // "समय बताओ", "टाइम बताओ", "क्या समय हुआ है", "time", "what time is it", "samay batao", "time batao"
  const isTimeCommand =
    lower === 'time' ||
    lower.includes('current time') ||
    lower.includes('what time is it') ||
    lower.includes('what is the time') ||
    lower.includes('samay') ||
    lower.includes('time batao') ||
    text.includes('समय बताओ') ||
    text.includes('टाइम बताओ') ||
    text.includes('समय क्या हुआ') ||
    text.includes('कितने बजे');

  if (isTimeCommand) {
    const now = new Date();
    const timeEn = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
    const hours = now.getHours();
    const period = hours >= 12 ? 'दोपहर/शाम' : 'सुबह';
    const spoken = `सर, अभी समय ${timeEn} हुआ है।`;
    const display = `🕒 **वर्तमान समय**: ${timeEn} (${period})\nJARVIS समय सिंक्रनाइज़ेशन पूर्ण।`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'info',
    };
  }

  // 4. DATE COMMAND
  // "आज की तारीख बताओ", "तारीख बताओ", "date", "today's date", "aaj ki tarikh batao"
  const isDateCommand =
    lower === 'date' ||
    lower.includes("today's date") ||
    lower.includes('what is the date') ||
    lower.includes('tarikh') ||
    lower.includes('taareekh') ||
    lower.includes('date batao') ||
    text.includes('तारीख बताओ') ||
    text.includes('तारीख क्या है') ||
    text.includes('आज की तारीख');

  if (isDateCommand) {
    const now = new Date();
    const dateEn = now.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const dateHi = now.toLocaleDateString('hi-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });

    const spoken = `सर, आज ${dateHi} है।`;
    const display = `📅 **आज की तारीख**:\n${dateEn}\n🇮🇳 ${dateHi}`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'info',
    };
  }

  // 5. BATTERY COMMAND
  // "battery kitni hai?", "बैटरी कितनी है?", "battery batao", "बैटरी बताओ", "battery status"
  const isBatteryCommand =
    lower.includes('battery') ||
    lower.includes('battery kitni hai') ||
    lower.includes('battery batao') ||
    text.includes('बैटरी') ||
    text.includes('बैटरी बताओ') ||
    text.includes('बैटरी कितनी है');

  if (isBatteryCommand) {
    if (typeof window !== 'undefined' && window.AndroidBridge?.getBatteryLevel) {
      const nativeLevel = window.AndroidBridge.getBatteryLevel();
      const isCharging = window.AndroidBridge.isBatteryCharging ? window.AndroidBridge.isBatteryCharging() : false;
      if (nativeLevel >= 0) {
        const chargingTextHi = isCharging ? 'चार्जिंग चालू है' : 'डिस्चार्ज हो रही है';
        const chargingTextEn = isCharging ? 'Charging' : 'Discharging';
        const spoken = `सर, आपके एंड्रॉइड फोन की बैटरी ${nativeLevel} प्रतिशत है और ${chargingTextHi}।`;
        const display = `🔋 **फोन बैटरी स्थिति**:\n• स्तर: **${nativeLevel}%**\n• स्थिति: **${chargingTextEn}**\n• स्रोत: Android System API`;

        return {
          handled: true,
          spokenReply: spoken,
          displayText: display,
          actionType: 'info',
          metadata: { levelPercent: nativeLevel, charging: isCharging },
        };
      }
    }

    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const battery: any = await (navigator as any).getBattery();
        const levelPercent = Math.round(battery.level * 100);
        const charging = battery.charging;

        const chargingTextHi = charging ? 'चार्जिंग चालू है' : 'चार्जिंग पर नहीं है';
        const chargingTextEn = charging ? 'Charging' : 'Discharging';
        const spoken = `सर, आपकी डिवाइस की बैटरी ${levelPercent} प्रतिशत है और ${chargingTextHi}।`;
        const display = `🔋 **बैटरी स्थिति**:\n• स्तर: **${levelPercent}%**\n• स्थिति: **${chargingTextEn}**\n• स्वास्थ्य: सामान्य`;

        return {
          handled: true,
          spokenReply: spoken,
          displayText: display,
          actionType: 'info',
          metadata: { levelPercent, charging },
        };
      } catch {
        // Fallback below
      }
    }

    const spokenFallback = `सर, वर्तमान ब्राउज़र में बैटरी API समर्थित नहीं है या अनुमति प्रतिबंधित है।`;
    const displayFallback = `🔋 **बैटरी स्थिति**:\nब्राउज़र सुरक्षा प्रतिबंधों के कारण बैटरी स्तर उपलब्ध नहीं है (Battery API restricted in sandbox).`;
    return {
      handled: true,
      spokenReply: spokenFallback,
      displayText: displayFallback,
      actionType: 'info',
    };
  }

  // 6. INTERNET / NETWORK STATUS
  // "internet chal raha hai?", "internet batao", "net chal raha hai", "network status"
  const isInternetCommand =
    lower.includes('internet') ||
    lower.includes('network') ||
    lower.includes('net chal') ||
    lower.includes('online status') ||
    text.includes('इंटरनेट') ||
    text.includes('नेटवर्क') ||
    text.includes('नेट चल रहा');

  if (isInternetCommand) {
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    const connection: any = (navigator as any)?.connection;
    const connectionType = connection?.effectiveType ? `(${connection.effectiveType.toUpperCase()} गति)` : '';

    if (isOnline) {
      const spoken = `सर, आपका इंटरनेट कनेक्शन चालू और सक्रिय है। JARVIS ऑनलाइन है।`;
      const display = `🌐 **इंटरनेट स्थिति**: ✅ **सक्रिय (ONLINE)**\nनेटवर्क लिंक: स्थिर ${connectionType}\nJARVIS सर्वर से सफलतापूर्वक जुड़ा हुआ है।`;
      return {
        handled: true,
        spokenReply: spoken,
        displayText: display,
        actionType: 'info',
      };
    } else {
      const spoken = `चेतावनी सर, आपका डिवाइस इंटरनेट से डिस्कनेक्टेड प्रतीत होता है।`;
      const display = `🌐 **इंटरनेट स्थिति**: ❌ **ऑफ़लाइन (OFFLINE)**\nकृपया अपने वाई-फ़ाई या मोबाइल डेटा की जाँच करें।`;
      return {
        handled: true,
        spokenReply: spoken,
        displayText: display,
        actionType: 'info',
      };
    }
  }

  // 7. GOOGLE OPEN OR SEARCH COMMAND
  // "Google kholo", "open google", "Google par search karo", "गूगल खोलो"
  const isGoogleOpen =
    lower === 'google' ||
    lower === 'open google' ||
    lower === 'google kholo' ||
    lower === 'google open karo' ||
    text.includes('गूगल खोलो') ||
    text.includes('गूगल ओपन करो');

  if (isGoogleOpen) {
    const url = 'https://www.google.com';
    const spoken = `सर, Google खोला जा रहा है।`;
    const display = `🔍 **Google ओपनर**:\nGoogle का मुख्य पृष्ठ खोलने के लिए नीचे क्लिक करें।`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionUrl: url,
      actionLabel: 'Open Google Homepage',
      actionType: 'url',
    };
  }

  const isGoogleSearch =
    lower.startsWith('google search') ||
    lower.startsWith('search google') ||
    (lower.includes('google') && (lower.includes('search') || lower.includes('khojo') || text.includes('सर्च') || text.includes('खोजो') || lower.includes('pe search') || lower.includes('par search')));

  if (isGoogleSearch) {
    let query = text
      .replace(/google/gi, '')
      .replace(/search/gi, '')
      .replace(/सर्च\s*करो/gi, '')
      .replace(/सर्च/gi, '')
      .replace(/खोजो/gi, '')
      .replace(/पर/gi, '')
      .replace(/pe/gi, '')
      .replace(/par/gi, '')
      .replace(/for/gi, '')
      .replace(/on/gi, '')
      .replace(/karo/gi, '')
      .replace(/kijiye/gi, '')
      .replace(/[?!.]+$/g, '')
      .trim();

    if (!query) query = 'Google Search';

    const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    const spoken = `सर, Google पर "${query}" खोज रहा हूँ।`;
    const display = `🔍 **Google Search**:\n• खोज क्वेरी: "${query}"\nGoogle खोज परिणाम खोलने के लिए नीचे दिए गए बटन पर टैप करें।`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionUrl: url,
      actionLabel: `Open Google ("${query}")`,
      actionType: 'url',
    };
  }

  // 8. YOUTUBE OPEN OR SEARCH COMMAND
  // "YouTube kholo", "open youtube", "YouTube par coding search karo", "यूट्यूब खोलो"
  const isYoutubeOpen =
    lower === 'youtube' ||
    lower === 'open youtube' ||
    lower === 'youtube kholo' ||
    lower === 'youtube open karo' ||
    text.includes('यूट्यूब खोलो') ||
    text.includes('यूट्यूब ओपन करो');

  if (isYoutubeOpen) {
    const url = 'https://www.youtube.com';
    const spoken = `सर, YouTube खोला जा रहा है।`;
    const display = `▶️ **YouTube ओपनर**:\nYouTube खोलने के लिए लिंक तैयार है।`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionUrl: url,
      actionLabel: 'Open YouTube',
      actionType: 'url',
    };
  }

  const isYoutubeSearch =
    lower.startsWith('youtube search') ||
    lower.startsWith('search youtube') ||
    (lower.includes('youtube') && (lower.includes('search') || lower.includes('khojo') || text.includes('सर्च') || text.includes('खोजो') || lower.includes('pe search') || lower.includes('par search') || lower.includes('coding search')));

  if (isYoutubeSearch) {
    let query = text
      .replace(/youtube/gi, '')
      .replace(/यूट्यूब/gi, '')
      .replace(/search/gi, '')
      .replace(/सर्च\s*करो/gi, '')
      .replace(/सर्च/gi, '')
      .replace(/खोजो/gi, '')
      .replace(/पर/gi, '')
      .replace(/pe/gi, '')
      .replace(/par/gi, '')
      .replace(/for/gi, '')
      .replace(/on/gi, '')
      .replace(/karo/gi, '')
      .replace(/kijiye/gi, '')
      .replace(/video/gi, '')
      .replace(/[?!.]+$/g, '')
      .trim();

    if (!query) query = 'Trending Videos';

    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
    const spoken = `सर, YouTube पर "${query}" सर्च कर रहा हूँ।`;
    const display = `▶️ **YouTube Search**:\n• खोज: "${query}"\nवीडियो परिणाम देखने के लिए नीचे दिए गए बटन पर टैप करें।`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionUrl: url,
      actionLabel: `Watch on YouTube ("${query}")`,
      actionType: 'url',
    };
  }

  // 9. WHATSAPP COMMAND
  // "WhatsApp खोलो", "whatsapp", "open whatsapp", "whatsapp kholo"
  const isWhatsappCommand =
    lower.includes('whatsapp') ||
    lower.includes('whats app') ||
    text.includes('व्हाट्सएप') ||
    text.includes('व्हाट्सऐप');

  if (isWhatsappCommand) {
    const numMatch = text.match(/\b\d{10,13}\b/);
    const targetUrl = numMatch ? `https://wa.me/${numMatch[0]}` : `https://web.whatsapp.com/`;
    const label = numMatch ? `Chat with ${numMatch[0]} on WhatsApp` : `Open WhatsApp Web`;

    const spoken = `सर, WhatsApp तैयार है।`;
    const display = `💬 **WhatsApp इंटीग्रेशन**:\nWhatsApp लॉन्च करने के लिए नीचे दिए गए बटन पर टैप करें।`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionUrl: targetUrl,
      actionLabel: label,
      actionType: 'url',
    };
  }

  // 10. CALL / PHONE DIALER COMMAND (tel:)
  // "Mummy ko call karo", "Call [number]", "कॉल [number]", "phone lagao", "dial [number]"
  const isCallCommand =
    lower.startsWith('call') ||
    lower.startsWith('dial') ||
    lower.includes('phone lagao') ||
    lower.includes('call karo') ||
    lower.includes('ko call') ||
    text.includes('कॉल') ||
    text.includes('फोन लगाओ') ||
    text.includes('डायल');

  if (isCallCommand) {
    // Extract phone digits if present
    const digits = text.replace(/\D/g, '');
    let targetNumber = digits;

    // Extract name or recipient
    let recipient = text
      .replace(/call/gi, '')
      .replace(/dial/gi, '')
      .replace(/phone/gi, '')
      .replace(/lagao/gi, '')
      .replace(/karo/gi, '')
      .replace(/kijiye/gi, '')
      .replace(/ko/gi, '')
      .replace(/को/gi, '')
      .replace(/कॉल\s*करो/gi, '')
      .replace(/कॉल/gi, '')
      .replace(/फोन/gi, '')
      .replace(/डायल/gi, '')
      .replace(/[?!.]+$/g, '')
      .trim();

    if (!targetNumber && recipient) {
      targetNumber = recipient;
    }

    let nativeDialerOpened = false;
    if (typeof window !== 'undefined' && window.AndroidBridge?.openDialer) {
      nativeDialerOpened = window.AndroidBridge.openDialer(digits || targetNumber);
    }

    const telUrl = digits ? `tel:${digits}` : 'tel:';
    const spoken = digits
      ? `सर, ${digits} पर कॉल करने के लिए फ़ोन डायलर खोला जा रहा है।`
      : recipient
        ? `सर, ${recipient} के लिए फ़ोन डायलर खोला जा रहा है। नंबर डायल करें।`
        : `सर, कृपया फ़ोन नंबर बताएं या डायलर खोलें।`;

    const display = `📞 **फ़ोन डायलर कमांड**:\n• संपर्क/नंबर: **${recipient || targetNumber || 'डायलर'}**\n${nativeDialerOpened ? '✅ एंड्रॉइड सिस्टम डायलर स्क्रीन खोली गई।' : '⚠️ डायलर खोलने के लिए नीचे टैप करें।'}`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionUrl: telUrl,
      actionLabel: `📞 Call ${targetNumber || 'Phone Dialer'}`,
      actionType: 'dialer',
      metadata: { number: digits || targetNumber },
    };
  }

  // 11. HELP COMMAND
  const isHelpCommand =
    lower === 'help' ||
    lower === 'help me' ||
    lower === 'commands' ||
    lower === 'smart commands' ||
    lower === 'kya kar sakte ho' ||
    lower.includes('what can you do') ||
    text.includes('मदद') ||
    text.includes('कमांड्स') ||
    text.includes('हेल्प');

  if (isHelpCommand) {
    const spoken = `सर, मैं आपके एंड्रॉइड फोन को नियंत्रित कर सकता हूँ जैसे फ्लैशलाइट, वॉल्यूम, वाई-फाई और ब्लूटूथ सेटिंग्स, ऐप्स लॉन्च, कॉल डायलर, म्यूजिक प्लेबैक, समय, तारीख, बैटरी, और Gemini AI द्वारा हर सवाल का जवाब दे सकता हूँ।`;
    const display = `⚡ **JARVIS V6 स्मार्ट एवं एंड्रॉइड कमांड सूची**:
1. **फोन हार्डवेयर**: "Turn on/off flashlight", "Increase/decrease volume", "Mute volume"
2. **सिस्टम सेटिंग्स**: "Open settings", "Open WiFi", "Open Bluetooth", "Battery settings"
3. **ऐप लॉन्चर**: "Open WhatsApp", "Open YouTube", "Open Camera", "Open Chrome"
4. **कॉल डायलर**: "Call [name/number]", "Mummy ko call karo"
5. **म्यूजिक कंट्रोल**: "Play music", "Pause music", "Next song", "Previous song"
6. **गणना (Math)**: "2+2 kitna hai?", "5 plus 5 kitna hai?", "10 * 5"
7. **डिवाइस स्थिति**: "समय बताओ", "आज की तारीख", "Battery बताओ", "Internet status"
8. **वेब सर्च**: "Google खोलो", "YouTube पर [query] search करो"
9. **Gemini AI Core**: किसी भी ज्ञान, कोडिंग, अनुवाद या जटिल विषय पर बातचीत करें!`;

    return {
      handled: true,
      spokenReply: spoken,
      displayText: display,
      actionType: 'help',
    };
  }

  // Not a local smart command -> Return null to route to Gemini AI
  return null;
}
