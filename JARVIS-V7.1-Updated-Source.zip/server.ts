import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Enable CORS for Android APK WebView and external clients
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  if (req.method === "OPTIONS") {
    res.sendStatus(200);
    return;
  }
  next();
});

app.use(express.json({ limit: "5mb" }));

// Lazy GoogleGenAI initialization
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not set in environment.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get("/api/health", (_req, res) => {
  res.json({
    status: "online",
    system: "JARVIS V7 Core",
    version: "7.0.0",
    versionCode: 7,
    timestamp: new Date().toISOString(),
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
  });
});

// APK Download endpoint (V7 primary, backwards-compatible fallback)
app.get(["/api/download-apk", "/api/download-apk-v7"], (_req, res) => {
  const candidatePaths = [
    path.join(process.cwd(), "public", "jarvis-v7-debug.apk"),
    path.join(process.cwd(), "android", "jarvis-v7-debug.apk"),
    path.join(process.cwd(), "android", "app", "build", "outputs", "apk", "debug", "app-debug.apk"),
    path.join(process.cwd(), "public", "jarvis-v6-debug.apk"),
    path.join(process.cwd(), "android", "jarvis-v6-debug.apk"),
  ];

  for (const apkPath of candidatePaths) {
    if (fs.existsSync(apkPath)) {
      res.setHeader("Content-Type", "application/vnd.android.package-archive");
      res.setHeader("Content-Disposition", 'attachment; filename="jarvis-v7-debug.apk"');
      return res.sendFile(apkPath);
    }
  }

  res.status(404).json({ error: "APK file not found. Please trigger build." });
});

// Android Project ZIP Download endpoint
app.get(["/api/download-project-zip", "/api/download-project-zip-v7"], (_req, res) => {
  const zipPath = fs.existsSync(path.join(process.cwd(), "public", "jarvis-v7-android-project.zip"))
    ? path.join(process.cwd(), "public", "jarvis-v7-android-project.zip")
    : path.join(process.cwd(), "public", "jarvis-v6-android-project.zip");
  if (fs.existsSync(zipPath)) {
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", 'attachment; filename="jarvis-v7-android-project.zip"');
    return res.sendFile(zipPath);
  }
  res.status(404).json({ error: "Project ZIP not found." });
});

// APK status endpoint
app.get("/api/apk-status", (_req, res) => {
  const apkPath = fs.existsSync(path.join(process.cwd(), "public", "jarvis-v7-debug.apk"))
    ? path.join(process.cwd(), "public", "jarvis-v7-debug.apk")
    : path.join(process.cwd(), "public", "jarvis-v6-debug.apk");
  const zipPath = fs.existsSync(path.join(process.cwd(), "public", "jarvis-v7-android-project.zip"))
    ? path.join(process.cwd(), "public", "jarvis-v7-android-project.zip")
    : path.join(process.cwd(), "public", "jarvis-v6-android-project.zip");
  
  const apkExists = fs.existsSync(apkPath);
  const zipExists = fs.existsSync(zipPath);

  res.json({
    version: "7.0.0",
    versionCode: 7,
    applicationId: "com.jarvis.ai",
    apkAvailable: apkExists,
    apkSize: apkExists ? fs.statSync(apkPath).size : 0,
    apkFileName: "jarvis-v7-debug.apk",
    apkDownloadUrl: "/api/download-apk",
    zipAvailable: zipExists,
    zipSize: zipExists ? fs.statSync(zipPath).size : 0,
    zipDownloadUrl: "/api/download-project-zip",
  });
});

// Chat endpoint with session history, multi-model fallback, and Google Search Grounding
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [], enableSearch = false } = req.body;

    if (!message || typeof message !== "string") {
      res.status(400).json({ error: "Missing or invalid 'message' field." });
      return;
    }

    const ai = getAI();

    const systemInstruction = `You are JARVIS V6 (Just A Rather Very Intelligent System), an advanced, ultra-responsive AI assistant.
Key Directives:
1. Natural Multilingualism: Seamlessly understand and respond in natural Hindi, Hinglish, or English based on user speech.
   - If spoken to in Hindi or Hinglish, answer in clear, polite, natural Hindi/Hinglish.
   - If spoken to in English, reply in crisp, professional English.
2. Voice-Ready & Crisp: Responses are spoken aloud via browser TTS. Keep answers concise, direct, conversational, and natural to hear (1-2 sentences for questions, crisp bullet points if listing). Avoid long disclaimers or heavy formatting.
3. Persona: Courteous, respectful (addressing the user as Sir/Boss/सर where natural), sharp, and technologically sophisticated.
4. Memory & Context: Remember previous conversation turns in the session (e.g., user's name, preferences, or topics discussed). When user introduces themselves like "Mera naam Manohar hai", acknowledge warmly, and when asked follow-ups like "Main kaun hoon?" or "Mera naam kya hai?", answer accurately.
5. Device Realism: You are running inside a browser environment. Never claim you can secretly make private phone calls or access restricted OS hardware outside standard browser sandbox permissions.`;

    // Sanitize and structure conversation history for Gemini API
    const contents: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      // Filter out non-conversational boilerplate or error messages
      const validItems = history.filter((item: any) => {
        if (!item || !item.text || typeof item.text !== "string") return false;
        const txt = item.text.trim();
        if (txt.startsWith("⚠️") || txt.includes("AI service se response")) return false;
        return item.role === "user" || item.role === "model";
      });

      // Gemini multi-turn must begin with a 'user' turn. Drop leading 'model' messages (e.g. initial greeting).
      let startIndex = 0;
      while (startIndex < validItems.length && validItems[startIndex].role !== "user") {
        startIndex++;
      }

      let lastRole: "user" | "model" | null = null;
      for (let i = startIndex; i < validItems.length; i++) {
        const item = validItems[i];
        const role = item.role === "model" ? "model" : "user";
        if (role === lastRole && contents.length > 0) {
          contents[contents.length - 1].parts[0].text += "\n" + item.text;
        } else {
          contents.push({
            role,
            parts: [{ text: String(item.text) }],
          });
          lastRole = role;
        }
      }
    }

    // Append current user message
    if (contents.length > 0 && contents[contents.length - 1].role === "user") {
      // If previous turn was also user, append to it or replace if identical
      if (contents[contents.length - 1].parts[0].text !== message) {
        contents[contents.length - 1].parts[0].text += "\n" + message;
      }
    } else {
      contents.push({
        role: "user",
        parts: [{ text: message }],
      });
    }

    const config: Record<string, any> = {
      systemInstruction,
      temperature: 0.7,
      maxOutputTokens: 600,
    };

    // Candidate models (attempt user choice if specified, followed by highly reliable models)
    const preferred = preferredModel && preferredModel !== "auto" ? preferredModel : null;
    const candidateModels = Array.from(
      new Set(
        [
          preferred,
          "gemini-3.5-flash",
          "gemini-3.1-flash-lite",
          "gemini-3.8-flash",
          "gemini-flash-latest",
        ].filter(Boolean) as string[]
      )
    );
    let response: any = null;
    let lastError: any = null;

    for (const modelName of candidateModels) {
      try {
        response = await ai.models.generateContent({
          model: modelName,
          contents: contents.length === 1 ? message : contents,
          config,
        });
        if (response && response.text) {
          break;
        }
      } catch (err: any) {
        lastError = err;
        // Continue seamlessly to next candidate model
      }
    }

    if (!response || !response.text) {
      throw lastError || new Error("Unable to obtain response from Gemini AI models.");
    }

    const replyText = response.text.trim();

    // Extract grounding sources if search was used
    const sources: Array<{ title: string; uri: string }> = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (Array.isArray(chunks)) {
      for (const chunk of chunks) {
        if (chunk.web && chunk.web.uri) {
          sources.push({
            title: chunk.web.title || "Web Source",
            uri: chunk.web.uri,
          });
        }
      }
    }

    const searchQueries = response.candidates?.[0]?.groundingMetadata?.webSearchQueries || [];

    res.json({
      reply: replyText,
      sources,
      searchQueries,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error("Technical error in /api/chat:", error);
    const techMsg = error?.message || String(error);
    res.status(503).json({
      error: "AI service se response nahi aa pa raha. Network ya API settings check kar raha hoon.",
      details: techMsg,
    });
  }
});

// Ultra-Fast Streaming Chat Endpoint (Server-Sent Events)
app.post("/api/chat/stream", async (req, res) => {
  try {
    const { message, history = [], enableSearch = false, preferredModel } = req.body;

    if (!message || typeof message !== "string") {
      res.status(400).json({ error: "Missing or invalid 'message' field." });
      return;
    }

    const ai = getAI();

    // Set SSE headers for real-time chunk delivery
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no"); // Disable proxy buffering
    res.flushHeaders();

    const systemInstruction = `You are JARVIS V6 (Just A Rather Very Intelligent System), an advanced, ultra-responsive AI assistant.
Key Directives:
1. Natural Multilingualism: Seamlessly understand and respond in natural Hindi, Hinglish, or English based on user speech.
   - If spoken to in Hindi or Hinglish, answer in clear, polite, natural Hindi/Hinglish.
   - If spoken to in English, reply in crisp, professional English.
2. Voice-Ready & Crisp: Responses are spoken aloud via browser TTS. Keep answers concise, direct, conversational, and natural to hear (1-2 sentences for questions, crisp bullet points if listing). Avoid long disclaimers or markdown formatting.
3. Persona: Courteous, respectful (addressing the user as Sir/Boss/सर where natural), sharp, and technologically sophisticated.
4. Memory & Context: Remember previous conversation turns in the session (e.g., user's name, preferences, or topics discussed). When user introduces themselves like "Mera naam Manohar hai", acknowledge warmly, and when asked follow-ups like "Main kaun hoon?" or "Mera naam kya hai?", answer accurately.
5. Device Realism: You are running inside a phone/browser environment. Offline device controls (torch, volume, apps, dialer) are executed by the local client.`;

    const contents: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      const validItems = history.filter((item: any) => {
        if (!item || !item.text || typeof item.text !== "string") return false;
        const txt = item.text.trim();
        if (txt.startsWith("⚠️") || txt.includes("AI service se response")) return false;
        return item.role === "user" || item.role === "model";
      });

      let startIndex = 0;
      while (startIndex < validItems.length && validItems[startIndex].role !== "user") {
        startIndex++;
      }

      let lastRole: "user" | "model" | null = null;
      for (let i = startIndex; i < validItems.length; i++) {
        const item = validItems[i];
        const role = item.role === "model" ? "model" : "user";
        if (role === lastRole && contents.length > 0) {
          contents[contents.length - 1].parts[0].text += "\n" + item.text;
        } else {
          contents.push({
            role,
            parts: [{ text: String(item.text) }],
          });
          lastRole = role;
        }
      }
    }

    if (contents.length > 0 && contents[contents.length - 1].role === "user") {
      if (contents[contents.length - 1].parts[0].text !== message) {
        contents[contents.length - 1].parts[0].text += "\n" + message;
      }
    } else {
      contents.push({
        role: "user",
        parts: [{ text: message }],
      });
    }

    const config: Record<string, any> = {
      systemInstruction,
      temperature: 0.7,
      maxOutputTokens: 600,
    };

    const preferred = preferredModel && preferredModel !== "auto" ? preferredModel : null;
    const candidateModels = Array.from(
      new Set(
        [
          preferred,
          "gemini-3.5-flash",
          "gemini-3.1-flash-lite",
          "gemini-3.8-flash",
          "gemini-flash-latest",
        ].filter(Boolean) as string[]
      )
    );

    let streamed = false;
    let lastError: any = null;

    for (const modelName of candidateModels) {
      try {
        const streamResult = await ai.models.generateContentStream({
          model: modelName,
          contents: contents.length === 1 ? message : contents,
          config,
        });

        for await (const chunk of streamResult) {
          const chunkText = chunk.text || "";
          if (chunkText) {
            res.write(`data: ${JSON.stringify({ text: chunkText, chunk: chunkText })}\n\n`);
            streamed = true;
          }
        }

        if (streamed) {
          break;
        }
      } catch (err: any) {
        lastError = err;
        // Seamlessly continue to next candidate model
      }
    }

    if (!streamed) {
      // Fallback: send single chunk with standard generateContent across candidates
      for (const fallbackModel of candidateModels) {
        try {
          const single = await ai.models.generateContent({
            model: fallbackModel,
            contents: contents.length === 1 ? message : contents,
            config,
          });
          const reply = single.text || "JARVIS ready.";
          res.write(`data: ${JSON.stringify({ text: reply, chunk: reply })}\n\n`);
          streamed = true;
          break;
        } catch (fallbackErr: any) {
          lastError = fallbackErr;
        }
      }
    }

    if (!streamed) {
      const fallbackMsg = lastError?.message || "AI service temporarily unavailable. Local device controls remain active.";
      res.write(`data: ${JSON.stringify({ error: fallbackMsg })}\n\n`);
    }

    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err: any) {
    console.error("Technical error in /api/chat/stream:", err);
    if (!res.headersSent) {
      res.status(503).json({ error: "Stream initialization error" });
    } else {
      res.write(`data: ${JSON.stringify({ error: err?.message || "Stream error" })}\n\n`);
      res.write("data: [DONE]\n\n");
      res.end();
    }
  }
});

// Vite middleware configuration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`JARVIS V5 Server running on port ${PORT}`);
  });
}

startServer();
